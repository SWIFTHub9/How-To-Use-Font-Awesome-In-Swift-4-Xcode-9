//
//  ViewController.swift
//  how to use font awsome in swift 4 xcode 9
//
//  Created by Abhishek Verma on 29/09/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        label.font = UIFont(name: "Font Awesome 5 Free", size: 60)
        label.text = "\u{f545} Ruller"
        
        button.titleLabel?.font = UIFont(name: "Font Awesome 5 Free", size: 30)
        button.setTitle("\u{f164} Like", for: .normal)
    }


}

